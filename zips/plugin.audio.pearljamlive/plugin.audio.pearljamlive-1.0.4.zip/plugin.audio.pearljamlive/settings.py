import xbmc, xbmcaddon, xbmcgui, xbmcplugin
import os

ADDON = xbmcaddon.Addon(id='plugin.audio.pearljamlive')
DATA_PATH = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.audio.pearljamlive'), '')
   
